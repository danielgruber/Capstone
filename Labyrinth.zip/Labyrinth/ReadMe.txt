Ersteller: Daniel Gruber
Gruppe 23

Parameters.txt can be modified to change behavior of level generator.